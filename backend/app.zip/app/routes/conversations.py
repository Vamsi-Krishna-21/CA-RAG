from datetime import datetime
import secrets

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.database.mongodb import get_db
from app.auth.authentication import get_current_user, parse_object_id
from app.models.conversation import new_conversation_doc


router = APIRouter(
    prefix="/api/conversations",
    tags=["conversations"],
)


class CreateConversationRequest(BaseModel):
    title: str = "New chat"
    document_ids: list[str] = []


class RenameConversationRequest(BaseModel):
    title: str


class DocumentsRequest(BaseModel):
    document_ids: list[str]


@router.get("")
async def list_conversations(
    current_user: dict = Depends(get_current_user),
):
    db = get_db()

    cursor = (
        db.conversations
        .find({
            "user_id": current_user["id"],
            "archived": False,
        })
        .sort([
            ("pinned", -1),
            ("updated_at", -1),
        ])
    )

    conversations = []

    async for conversation in cursor:
        conversations.append({
            "id": str(conversation["_id"]),
            "title": conversation["title"],
            "document_ids": conversation.get("document_ids", []),
            "pinned": conversation.get("pinned", False),
            "archived": conversation.get("archived", False),
            "created_at": conversation["created_at"].isoformat(),
            "updated_at": conversation["updated_at"].isoformat(),
        })

    return conversations


@router.post("")
async def create_conversation(
    payload: CreateConversationRequest,
    current_user: dict = Depends(get_current_user),
):
    db = get_db()

    title = payload.title.strip() or "New chat"

    # Verify that every selected document belongs to this user.
    if payload.document_ids:
        valid_documents = await db.documents.count_documents({
            "user_id": current_user["id"],
            "_id": {
                "$in": [
                    oid
                    for oid in (
                        parse_object_id(doc_id)
                        for doc_id in payload.document_ids
                    )
                    if oid is not None
                ]
            },
        })

        if valid_documents != len(set(payload.document_ids)):
            raise HTTPException(
                status_code=404,
                detail="One or more documents were not found",
            )

    conversation = new_conversation_doc(
        current_user["id"],
        title,
        list(dict.fromkeys(payload.document_ids)),
    )

    result = await db.conversations.insert_one(conversation)

    return {
        "id": str(result.inserted_id),
        "title": conversation["title"],
        "document_ids": conversation["document_ids"],
        "pinned": conversation["pinned"],
        "archived": conversation["archived"],
        "created_at": conversation["created_at"].isoformat(),
        "updated_at": conversation["updated_at"].isoformat(),
    }


@router.patch("/{conversation_id}")
async def rename_conversation(
    conversation_id: str,
    payload: RenameConversationRequest,
    current_user: dict = Depends(get_current_user),
):
    db = get_db()

    oid = parse_object_id(conversation_id)

    if not oid:
        raise HTTPException(
            status_code=400,
            detail="Invalid conversation ID",
        )

    title = payload.title.strip()

    if not title:
        raise HTTPException(
            status_code=400,
            detail="Conversation title cannot be empty",
        )

    result = await db.conversations.update_one(
        {
            "_id": oid,
            "user_id": current_user["id"],
        },
        {
            "$set": {
                "title": title,
                "updated_at": datetime.utcnow(),
            }
        },
    )

    if result.matched_count == 0:
        raise HTTPException(
            status_code=404,
            detail="Conversation not found",
        )

    return {
        "id": conversation_id,
        "title": title,
    }


@router.post("/{conversation_id}/pin")
async def toggle_pin(
    conversation_id: str,
    current_user: dict = Depends(get_current_user),
):
    db = get_db()

    oid = parse_object_id(conversation_id)

    if not oid:
        raise HTTPException(
            status_code=400,
            detail="Invalid conversation ID",
        )

    conversation = await db.conversations.find_one({
        "_id": oid,
        "user_id": current_user["id"],
    })

    if not conversation:
        raise HTTPException(
            status_code=404,
            detail="Conversation not found",
        )

    new_value = not conversation.get("pinned", False)

    await db.conversations.update_one(
        {"_id": oid},
        {
            "$set": {
                "pinned": new_value,
                "updated_at": datetime.utcnow(),
            }
        },
    )

    return {
        "id": conversation_id,
        "pinned": new_value,
    }


@router.post("/{conversation_id}/archive")
async def toggle_archive(
    conversation_id: str,
    current_user: dict = Depends(get_current_user),
):
    db = get_db()

    oid = parse_object_id(conversation_id)

    if not oid:
        raise HTTPException(
            status_code=400,
            detail="Invalid conversation ID",
        )

    conversation = await db.conversations.find_one({
        "_id": oid,
        "user_id": current_user["id"],
    })

    if not conversation:
        raise HTTPException(
            status_code=404,
            detail="Conversation not found",
        )

    new_value = not conversation.get("archived", False)

    await db.conversations.update_one(
        {"_id": oid},
        {
            "$set": {
                "archived": new_value,
                "updated_at": datetime.utcnow(),
            }
        },
    )

    return {
        "id": conversation_id,
        "archived": new_value,
    }


@router.delete("/{conversation_id}")
async def delete_conversation(
    conversation_id: str,
    current_user: dict = Depends(get_current_user),
):
    db = get_db()

    oid = parse_object_id(conversation_id)

    if not oid:
        raise HTTPException(
            status_code=400,
            detail="Invalid conversation ID",
        )

    conversation = await db.conversations.find_one({
        "_id": oid,
        "user_id": current_user["id"],
    })

    if not conversation:
        raise HTTPException(
            status_code=404,
            detail="Conversation not found",
        )

    await db.messages.delete_many({
        "user_id": current_user["id"],
        "conversation_id": conversation_id,
    })

    await db.conversations.delete_one({
        "_id": oid,
        "user_id": current_user["id"],
    })

    return {
        "detail": "Conversation deleted",
    }


@router.post("/{conversation_id}/share")
async def share_conversation(
    conversation_id: str,
    current_user: dict = Depends(get_current_user),
):
    db = get_db()

    oid = parse_object_id(conversation_id)

    if not oid:
        raise HTTPException(
            status_code=400,
            detail="Invalid conversation ID",
        )

    conversation = await db.conversations.find_one({
        "_id": oid,
        "user_id": current_user["id"],
    })

    if not conversation:
        raise HTTPException(
            status_code=404,
            detail="Conversation not found",
        )

    share_token = conversation.get("share_token")

    if not share_token:
        share_token = secrets.token_urlsafe(32)

        await db.conversations.update_one(
            {"_id": oid},
            {
                "$set": {
                    "share_token": share_token,
                    "updated_at": datetime.utcnow(),
                }
            },
        )

    return {
        "id": conversation_id,
        "share_token": share_token,
    }


@router.get("/{conversation_id}")
async def get_conversation(
    conversation_id: str,
    current_user: dict = Depends(get_current_user),
):
    db = get_db()

    oid = parse_object_id(conversation_id)

    if not oid:
        raise HTTPException(
            status_code=400,
            detail="Invalid conversation ID",
        )

    conversation = await db.conversations.find_one({
        "_id": oid,
        "user_id": current_user["id"],
    })

    if not conversation:
        raise HTTPException(
            status_code=404,
            detail="Conversation not found",
        )

    return {
        "id": str(conversation["_id"]),
        "title": conversation["title"],
        "document_ids": conversation.get("document_ids", []),
        "pinned": conversation.get("pinned", False),
        "archived": conversation.get("archived", False),
        "created_at": conversation["created_at"].isoformat(),
        "updated_at": conversation["updated_at"].isoformat(),
    }
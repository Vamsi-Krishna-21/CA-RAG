"""
Retrieves candidate chunks for a query (+ its rewrites) from the FAISS
indexes of one or more documents, ranks them globally, and returns the
top N.

These are CANDIDATES ONLY -- CA-RAG validation (carag_pipeline.py)
decides which ones actually count as evidence.

Supports:
- Single-PDF retrieval
- Multi-PDF retrieval
- Original query + rewritten queries
- Keyword scoring
- Feedback-based ranking
- Global ranking across all selected PDFs
"""

from app.services.embeddings import embed_text
from app.services import vector_store
from app.services.retrieval.ranking import keyword_score, combine_scores
from app.services.feedback.feedback_learning import get_feedback_boost


async def retrieve_candidates(
    document_ids: str | list[str],
    query_bundle: dict,
    top_k: int = 12,
):
    """
    Retrieve candidate chunks from one or more documents.

    Parameters
    ----------
    document_ids:
        A single document ID or a list of document IDs.

    query_bundle:
        Contains:
        - original_query
        - rewritten_queries
        - keywords

    top_k:
        Maximum number of candidates returned globally.

    Returns
    -------
    list[dict]
        Globally ranked candidate chunks from all selected documents.
    """

    # ---------------------------------------------------------------
    # Normalize document IDs
    # ---------------------------------------------------------------

    if isinstance(document_ids, str):
        document_ids = [document_ids]

    # Remove duplicates while preserving selection order.
    document_ids = list(dict.fromkeys(document_ids))

    if not document_ids:
        return []

    # ---------------------------------------------------------------
    # Build query variants
    # ---------------------------------------------------------------

    all_queries = [
        query_bundle["original_query"]
    ] + query_bundle.get("rewritten_queries", [])

    keywords = query_bundle.get("keywords", [])

    # ---------------------------------------------------------------
    # Retrieval state
    # ---------------------------------------------------------------

    seen = {}

    # Cache feedback boost by document + chunk.
    #
    # Using both document_id and chunk_id prevents accidental
    # collisions if two documents happen to contain the same chunk ID.
    boost_cache = {}

    # ---------------------------------------------------------------
    # Search every query against every selected document
    # ---------------------------------------------------------------

    for q in all_queries:

        # Embed the query only once.
        q_emb = embed_text(q)

        for document_id in document_ids:

            results = vector_store.search(
                document_id,
                q_emb,
                top_k=top_k,
            )

            for r in results:

                # ---------------------------------------------------
                # Preserve the source document
                # ---------------------------------------------------

                r["document_id"] = document_id

                # ---------------------------------------------------
                # Keyword relevance
                # ---------------------------------------------------

                kw = keyword_score(
                    r["text"],
                    keywords,
                )

                # ---------------------------------------------------
                # Feedback boost
                # ---------------------------------------------------

                chunk_id = r["chunk_id"]
                boost_key = (document_id, chunk_id)

                if boost_key not in boost_cache:
                    boost_cache[boost_key] = await get_feedback_boost(
                        chunk_id
                    )

                boost = boost_cache[boost_key]

                # ---------------------------------------------------
                # Combined retrieval score
                # ---------------------------------------------------

                r["retrieval_score"] = combine_scores(
                    r["semantic_score"],
                    kw,
                    boost,
                )

                # ---------------------------------------------------
                # Deduplicate the same chunk
                #
                # A chunk may match:
                #   - the original query
                #   - multiple rewritten queries
                #
                # Keep only its highest-scoring occurrence.
                # ---------------------------------------------------

                candidate_key = (
                    document_id,
                    chunk_id,
                )

                existing = seen.get(candidate_key)

                if (
                    existing is None
                    or r["retrieval_score"]
                    > existing["retrieval_score"]
                ):
                    seen[candidate_key] = r

    # ---------------------------------------------------------------
    # Global ranking across ALL selected documents
    # ---------------------------------------------------------------

    ranked = sorted(
        seen.values(),
        key=lambda r: r["retrieval_score"],
        reverse=True,
    )

    # ---------------------------------------------------------------
    # Return global top-k candidates
    # ---------------------------------------------------------------

    return ranked[:top_k]
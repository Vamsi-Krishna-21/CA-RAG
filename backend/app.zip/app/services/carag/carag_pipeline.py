"""
Orchestrates the CA-RAG validation stage:
  candidate chunks -> generate a candidate answer per chunk ->
  validate each against its source chunk -> keep only VALIDATED ones.

This is the step that separates CA-RAG from plain RAG: plain RAG would
hand every retrieved chunk straight to the final answer generator.
"""
import asyncio

from app.config import settings
from app.services.carag.candidate_generator import generate_candidate_answer
from app.services.carag.similarity_validator import validate_candidate


async def run_carag_validation(question: str, candidate_chunks: list, on_progress=None) -> list:
    """
    Candidate generation + similarity validation for every retrieved chunk.

    Each chunk is handled independently, so the LLM calls run concurrently
    (bounded by settings.carag_validation_concurrency). The decision logic is
    unchanged: same prompt per chunk, same validate_candidate() threshold, same
    ordering of the final list. Results are collected in the original chunk
    order before the (stable) similarity sort, so the output is identical to
    the previous sequential loop for identical candidate answers.

    on_progress(done, total) is an optional callback used by the streaming
    endpoint to report real progress; it has no effect on the result.
    """
    total = len(candidate_chunks)
    limit = max(1, int(settings.carag_validation_concurrency))
    semaphore = asyncio.Semaphore(limit)
    done = 0

    async def _process(chunk: dict) -> dict:
        nonlocal done
        async with semaphore:
            candidate_answer = await generate_candidate_answer(question, chunk["text"])
        result = validate_candidate(chunk, candidate_answer)
        done += 1
        if on_progress is not None:
            on_progress(done, total)
        return result

    results = await asyncio.gather(*(_process(chunk) for chunk in candidate_chunks))
    validated = [r for r in results if r["status"] == "VALIDATED"]
    # Strongest evidence first.
    validated.sort(key=lambda r: r["similarity"], reverse=True)
    return validated

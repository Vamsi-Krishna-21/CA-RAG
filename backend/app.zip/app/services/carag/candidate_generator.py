"""
For each retrieved chunk, asks the LLM to answer the question using ONLY
that chunk. This produces one candidate answer per chunk, which
similarity_validator.py then checks for alignment with the chunk it
came from.
"""
from app.services.llm_client import generate

SYSTEM_PROMPT = (
    "Answer the question using ONLY the provided text excerpt. "
    "If the excerpt does not contain the answer, say so plainly. "
    "Do not use outside knowledge."
)


async def generate_candidate_answer(question: str, chunk_text: str) -> str:
    prompt = f"Excerpt:\n{chunk_text}\n\nQuestion: {question}"
    return await generate(prompt, system=SYSTEM_PROMPT)

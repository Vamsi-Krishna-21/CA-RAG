"""
The central CA-RAG component: validates a candidate answer against the
chunk it was generated from, using cosine similarity between their
embeddings as an evidence-alignment signal (NOT treated as perfect proof).
Chunks whose candidate answer doesn't align with the chunk itself are
rejected -- this is what prevents ungrounded/drifted chunks from ever
reaching the final answer.
"""
from app.config import settings
from app.services.embeddings import embed_text
from app.utils.similarity import cosine_similarity


def validate_candidate(chunk: dict, candidate_answer: str) -> dict:
    answer_emb = embed_text(candidate_answer)
    chunk_emb = embed_text(chunk["text"])
    similarity = cosine_similarity(answer_emb, chunk_emb)
    status = "VALIDATED" if similarity >= settings.validation_similarity_threshold else "REJECTED"

    return {
        "chunk_id": chunk["chunk_id"],
        "answer": candidate_answer,
        "similarity": round(similarity, 4),
        "status": status,
        "page_start": chunk.get("page_start"),
        "page_end": chunk.get("page_end"),
        "section": chunk.get("section"),
        "text": chunk["text"],
    }

import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import Icon from '../common/Icon.jsx'
import { listConversations } from '../../services/conversationApi.js'

export default function SidebarDocuments({
  activeId,
  onNavigate,
}) {
  const [conversations, setConversations] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const loadConversations = async () => {
    try {
      setLoading(true)
      setError('')

      const data = await listConversations()

      setConversations(
        Array.isArray(data)
          ? data
          : [],
      )
    } catch (err) {
      setError(
        err?.message ||
        'Could not load recent chats.',
      )
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadConversations()

    const handleRefresh = () => {
      loadConversations()
    }

    window.addEventListener(
      'carag:conversation-updated',
      handleRefresh,
    )

    return () => {
      window.removeEventListener(
        'carag:conversation-updated',
        handleRefresh,
      )
    }
  }, [])

  return (
    <section
      className="side-docs"
      aria-label="Recent chats"
    >
      <div className="side-docs-head">
        <span className="side-heading">
          Recents
        </span>
      </div>

      {loading ? (
        <div className="side-note">
          Loading…
        </div>
      ) : error ? (
        <div
          className="side-note side-note-error"
          role="alert"
        >
          {error}
        </div>
      ) : conversations.length === 0 ? (
        <div className="side-note">
          No recent chats.
        </div>
      ) : (
        <ul className="side-doc-list">
          {conversations.map((conversation) => {
            /*
             * IMPORTANT:
             *
             * We do NOT use a document filename here.
             *
             * A conversation may contain multiple documents,
             * so the sidebar represents the conversation itself.
             */
            const title =
              conversation.title?.trim() ||
              'New chat'

            const conversationId =
              conversation.id

            return (
              <li key={conversationId}>
                <Link
                  to={`/chat?conversation=${conversationId}`}
                  className={
                    'side-doc' +
                    (
                      activeId === conversationId
                        ? ' active'
                        : ''
                    )
                  }
                  aria-current={
                    activeId === conversationId
                      ? 'true'
                      : undefined
                  }
                  title={title}
                  onClick={onNavigate}
                >
                  <Icon
                    name="chat"
                    size={16}
                  />

                  <span className="side-doc-name">
                    {title}
                  </span>
                </Link>
              </li>
            )
          })}
        </ul>
      )}
    </section>
  )
}